# Tools

Where each kind of data lives, and whether the agent can reach it. Loops read this before pulling data.

| Data | Tool | Connected? | Notes |
|---|---|---|---|
| Calendar | | | |
| Email | | | |
| Call recordings and transcripts | | | |
| CRM | | | |
| LinkedIn outreach | | | |
| Billing / revenue | | | |
| Product analytics | | | |
| Notifications (where the founder gets messages) | | | |
